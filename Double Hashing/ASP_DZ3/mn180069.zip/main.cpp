#include "HashTable.h"


#include <iostream>
#include<fstream>



void print()
{
	string s = "------------";
	cout << s << endl;
	cout << "1 - Find Key" << endl;
	cout << "2 - Insert Key" << endl;
	cout << "3 - Delete Key" << endl;
	cout << "4 - Clear" << endl;
	cout << "5 - Reset Statistics" << endl;
	cout << "6 - Average Success Acces" << endl;
	cout << "7 - Average Unsuccess Access" << endl;
	cout << "8 - Fill Ratio" << endl;
	cout << "9 - Get Key Count" << endl;
	cout << "10 - Print Table" << endl;
	cout << "11 - Get Table Size" << endl;
	cout << s << endl;
}

int main()
{
	const int N = 6;
	HashTable H(N);

	while (true)
	{
		print();
		string s, i, o;
		int x;
		cin >> x;
		switch (x)
		{
		case 1:
			cout << "Ime filma:\n"; 
			cin >> s;
			cout << H.findKey(s);
			break;
		case 2:
			cout << "Ime filma i opis:\n";
			cin >> i >> o;
			H.insertKey(i, o);
			break;
		case 3:
			cout << "Ime filma:\n";
			cin >> s;
			H.deleteKey(s);
			break;
		case 4:
			H.clear();
			break;
		case 5:
			
			break;
		case 6:
			cout << H.avgAccesSucces();
			break;
		case 7:
			cout << H.avgAccesUnsucces();
			break;
		case 8:
			cout << H.fillRatio();
			break;
		case 9:
			cout << H.getKeyCount();
			break;
		case 10:
			cout << H;
			break;
		case 11:
			cout << H.getKeyCount();
			break;
		default:
			break;
		}
	}

	return 0;
}