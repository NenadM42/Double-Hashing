#include "AdressFunction.h"



AdressFunction::AdressFunction()
{
}


AdressFunction::~AdressFunction()
{
}
